===============================================================================
 GMKI CABANG PADANG - PANDUAN PEMULIHAN BENCANA CADANGAN TOTAL (DISASTER RECOVERY)
 Waktu Pencadangan: 2026-10-17 23:08:30
 Berkas Cadangan: backup_total_gmki_padang_20261017_230828.zip
===============================================================================

STRUKTUR DIREKTORI CADANGAN:
1. database/         : Berisi dump basis data MySQL (.sql dan .sql.gz).
2. storage_private/  : Berisi dokumen rahasia, surat sekretariat, foto civitas & berkas KTA.
3. public_uploads/   : Berisi media berita, lampiran pengumuman, dan aset publik.
4. manifest.csv      : Daftar verifikasi keaslian SHA-256 untuk setiap berkas fisik.
5. backup_info.json  : Metadata konfigurasi dan ringkasan audit pencadangan.

LANGKAH-LANGKAH PEMULIHAN (RESTORE):
A. Pemulihan Basis Data:
   - Buka phpMyAdmin / MySQL CLI pada server tujuan.
   - Impor berkas 'database/database_dump_20261017_230828.sql' ke database MySQL yang aktif.

B. Pemulihan Berkas Media & Unggahan:
   - Salin isi folder 'storage_private/' ke direktori server: 'storage/private/'
   - Salin isi folder 'public_uploads/' ke direktori server: 'frontend/public/uploads/'

C. Verifikasi Integritas:
   - Periksa keaslian berkas dengan mencocokkan nilai hash SHA-256 pada 'manifest.csv'.

Dokumen ini dibuat otomatis oleh Sistem Informasi GMKI Cabang Padang.
